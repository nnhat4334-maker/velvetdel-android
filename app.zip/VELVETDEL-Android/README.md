# VELVETDEL — Android UI Prototype

**Nguồn tham chiếu:** https://www.figma.com/design/gH7uVg4OiqpRPxkJ6i7YJe/VELVETDEL-%E2%80%94-Luxury-Handbag-App-%C2%B7-UI-UX

**Trạng thái:** Mã nguồn Android chạy offline, **chưa được build hoặc kiểm thử trên thiết bị**. Tại môi trường tạo dự án không có Android SDK/Gradle, vì vậy KHÔNG có file `.apk` đã xác minh.

## Có những gì?

- 12 màn hình theo cấu trúc Figma: Splash, Giới thiệu, Trang chủ, Danh mục, Khám phá, Chi tiết, Yêu thích, Giỏ hàng, Thanh toán, Đơn hàng, Đăng nhập, Tài khoản.
- Giao diện web responsive trong ứng dụng Android WebView (Java), tối ưu kích thước Figma 390×844.
- Tìm sản phẩm, lọc danh mục, thêm/xóa yêu thích, cập nhật giỏ hàng, ưu đãi 5% từ 2 món, tạo đơn hàng demo và lưu thông tin vào bộ nhớ của ứng dụng.
- Không cần hosting, không cần Internet, không có quyền Internet trong AndroidManifest.
- Có thêm chế độ chạy thử trên trình duyệt máy tính.

## Quan trọng về dữ liệu và hình ảnh

**Đây là bản prototype, không phải app bán hàng production.** Đăng nhập là mô phỏng cục bộ, không có xác thực; đơn hàng chỉ lưu trên thiết bị, KHÔNG truyền cho cửa hàng; không kết nối thanh toán, quản lý tồn kho, hay máy chủ.

Chúng tôi đọc được các màn hình và thông số của Figma, nhưng truy xuất tài nguyên Figma bị hạn mức. Vì thế **hình sản phẩm hiện là SVG minh họa trong mã**, chưa phải hình gốc. Font chữ và một số chi tiết cũng có thể khác. Để khớp Figma pixel-perfect, cần xuất ảnh sản phẩm/assets và bổ sung sau.

## Xuất APK bằng Android Studio

1. Cài **Android Studio** bản hiện hành và Android SDK Platform 35, JDK 17.
2. Mở Android Studio → **Open** → chọn thư mục `VELVETDEL-Android` (thư mục chứa `settings.gradle`).
3. Cho Android Studio tải Gradle/Android Gradle Plugin nếu được đề nghị; kết nối Internet trên máy của bạn trong lần đầu tải thư viện. Dự án dùng Android Gradle Plugin 8.7.3, Java 17.
4. Chọn **Build → Build Bundle(s) / APK(s) → Build APK(s)** (tên menu có thể thay đổi theo phiên bản).
5. Bản debug dự kiến tại `app/build/outputs/apk/debug/app-debug.apk` sau khi build thành công. Có thể gửi file này cho điện thoại để cài thử. Chưa xác minh APK trong môi trường hiện tại.
6. Để phát hành chính thức, tạo **APK đã ký số** từ **Build → Generate Signed Bundle / APK**, bảo quản file keystore riêng; muốn lên Google Play hãy xuất AAB theo quy định tại thời điểm đăng.

*Lưu ý:* project không đính kèm `gradlew`/`gradle-wrapper.jar` vì môi trường tạo file không có bộ Gradle; Android Studio có thể nhập/sync project và cài đặt Gradle cần thiết. Nếu IDE yêu cầu gradle wrapper, hãy dùng Gradle đã cài trên máy chạy lệnh `gradle wrapper --gradle-version 8.9` trong thư mục gốc rồi mở lại dự án.

## Chạy thử trước khi build

Mở `VELVETDEL_Preview.html` trong trình duyệt trên desktop hoặc điện thoại. Đây là một file độc lập đã nhúng CSS/JS, chạy offline.

## Cấu trúc chính

- `app/src/main/assets/index.html`, `styles.css`, `app.js` — toàn bộ UI và logic demo.
- `app/src/main/java/com/velvetdel/app/MainActivity.java` — Android WebView shell.
- `app/src/main/AndroidManifest.xml` — cấu hình Android.
- `app/build.gradle` — thông số build.

## Các bước cần làm nếu muốn bán hàng thực tế

- Nhận assets nguyên bản từ Figma (ảnh túi, banners, logos, icons, fonts), so khớp từng màn.
- Triển khai API sản phẩm, giỏ hàng/đơn hàng thật, tồn kho, đăng nhập bảo mật, đồng bộ tài khoản.
- Thanh toán qua dịch vụ đáng tin cậy hoặc COD liên kết hệ thống quản trị, xác thực đơn và xử lý lỗi.
- Kiểm thử hiệu năng, bảo mật, truy cập, tương thích thiết bị và pháp lý trước khi phát hành.

*Không bao giờ sử dụng mật khẩu thật trong form đăng nhập demo.*

## Cách khác: Build APK bằng GitHub Actions (không cần cài Android Studio)

1. Tạo repository GitHub và tải **nội dung thư mục** `VELVETDEL-Android` lên thư mục gốc của repository (bao gồm cả `.github/workflows/build-apk.yml`).
2. Mở tab **Actions** → workflow **Build VELVETDEL Debug APK** → **Run workflow**.
3. Khi workflow báo thành công, mở lần chạy và tải artifact **VELVETDEL-debug-apk**. Giải nén để lấy `app-debug.apk`.

Workflow dùng hosted GitHub runner với JDK 17, Android SDK 35 và Gradle 8.9. Đây là quy trình build được cấu hình, **chưa được chạy và chưa xác minh thành công** trong môi trường hiện tại. Có thể cần quyền chạy GitHub Actions tùy cấu hình repository.
